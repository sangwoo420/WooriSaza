<template>
    <div>
    </div>
</template>


<script>
// import axios from "axios"
// import ogs from "open-graph-scraper"
// import {ogs} from "@/ogs.js"
export default {
    name: 'MyArticledetail',
    data() {
        return {
        };
    },
    created() {
    },
    mounted() {
    },

    methods: {
    },
};
</script>

<style scoped>
</style>