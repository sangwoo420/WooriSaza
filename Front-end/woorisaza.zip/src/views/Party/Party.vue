<template>
    <div class="mt-3" style="background-color : #FFFDF2; width:100%;height:100%">
            <div class="pt-5 pb-5">
                <!-- pc버전 -->
                <b-container >
                    <b-row class="">
                        <b-col></b-col>
                        <b-col cols="7">
                            <div :class="{box:true}" style="overflow-y:auto;">
                                <div class="p-5">
                                    <!-- <component :is="selectComponent"></component> -->
                                </div>
                            </div>
                        </b-col>
                        <b-col>
                        </b-col>
                    </b-row>
                </b-container>
            </div>
    </div>
</template>

<script>
export default {
    name: 'Party',

    data() {
        return {
            
        };
    },

    mounted() {
        
    },

    methods: {
        
    },
};
</script>

<style scoped>
.box{
        background-color:white; 
        box-shadow: 0px 0px 5px 0.1px grey; 
        border-radius: 0.5em;
        width:100%;
        height:100%;
        -ms-overflow-style: none; /* IE and Edge */
        scrollbar-width: none; /* Firefox */
    }
</style>