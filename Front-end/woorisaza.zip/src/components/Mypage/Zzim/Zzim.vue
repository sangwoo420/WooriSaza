<template>
    <div>
        {{zzimNo[0]}}프로필id 
        {{zzimNo[1]}}게시글id
        <div>
            <b-row>
                <b-col cols="8">
                    <div>
                        <div :class="{statebox:true}">거래 완료</div>
                        <div style="font-size:1.1em;font-weight:bold;cursor:pointer" @click="moveToDetail">물 24개 나누실 분</div>
                        <div style="font-size:0.9em">기간: ~22.2.1</div>
                        <div style="font-size:0.9em">모집인원: 4/4</div>
                        
                    </div>
                </b-col>
                <b-col cols="4">
                    <div style="text-align:right" class="mt-5">
                        <div style="font-size:0.9em; text-decoration:line-through" class="mt-3">10000원</div>
                        <div style="font-size:1.3em;font-weight:bold;">2500원</div>
                    </div>
                </b-col>
            </b-row>
            <hr>
        </div>
    </div>
</template>

<script>
export default {
    name: 'Zzim',
    props:["zzimNo"],
    data() {
        return {
            
        };
    },

    mounted() {
        
    },

    methods: {
        moveToDetail(){
            console.log("상세보기 페이지로 이동")
        },
    },
};
</script>

<style scoped>
.statebox{
      color: white ;
      font-size: 0.7em;
      background-color: red ;
      border-radius: 0.5em ;
      padding: 0.2em ;
      text-align: center;
      width: 5em;
      margin-bottom: 0.5em;
}
</style>