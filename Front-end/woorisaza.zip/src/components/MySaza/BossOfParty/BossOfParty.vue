<template>
    <div>
        <!-- 내가 참가한 파티 목록 -->
        <div v-for="(item, index) in partyList" :key="index">
            <Article :party="item"></Article>
        </div>
    </div>
</template>

<script>
import Article from "@/components/MySaza/BossOfParty/Article.vue";
import {axios_contact} from "@/common.js"

export default {
    name: 'Memberofparty',
    components:{
        Article,
    },
    data() {
        return {
            partyList:[],
            id : this.$route.params.id,
        };
    },

    created() {
        axios_contact({
            method : "get",
            url : "party/"+this.id,
        }).then(({data})=>{
            // console.log(data)
            for (let index = 0; index < data.length; index++) {
                if(data[index].isBoss){
                    this.partyList.push(data[index])
                }
            }
        })
    },
    mounted() {
        
    },

    methods: {
        
    },
};
</script>

<style lang="scss" scoped>

</style>